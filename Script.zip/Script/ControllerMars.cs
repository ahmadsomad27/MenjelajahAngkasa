﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerMars : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject PanelInfoMars;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoMars.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoMars.SetActive(false);
            show = false;
        }
    }
}
