﻿using UnityEngine;
using System.Collections;
using System.IO;

public class UIMatahariHibrid : MonoBehaviour
{
    public float scalingSpeed = 0.03f;
    public float rotationSpeed = 70.0f;
    public float translationSpeed = 5.0f;
    //	public GameObject Model;
    bool repeatScaleUp = false;
    bool repeatScaleDown = false;

    void Update()
    {
        if (repeatScaleUp)
        {
            ScaleUpButton();
        }

        if (repeatScaleDown)
        {
            ScaleDownButton();
        }
    }

    public void CloseAppButton()
    {
        Application.Quit();
    }

    public void ScaleUpButton()
    {
        GameObject.FindWithTag("mHibrid").transform.localScale += new Vector3(scalingSpeed, scalingSpeed, scalingSpeed);
    }

    public void ScaleUpButtonRepeat()
    {
        repeatScaleUp = true;
        Debug.Log("Up");
    }
    public void ScaleDownButtonRepeat()
    {
        repeatScaleDown = true;
        Debug.Log("Down");
    }
    public void ScaleUpButtonOff()
    {
        repeatScaleUp = false;
        Debug.Log("Off");
    }
    public void ScaleDownButtonOff()
    {
        repeatScaleDown = false;
        Debug.Log("Off");
    }

    public void ScaleDownButton()
    {
        GameObject.FindWithTag("mHibrid").transform.localScale += new Vector3(-scalingSpeed, -scalingSpeed, -scalingSpeed);
    }

    public void ChangeScene(string a)
    {
        Application.LoadLevel(a);
    }

    public void AnyButton()
    {
        Debug.Log("Any");
    }
}