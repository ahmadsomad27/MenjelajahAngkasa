﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerYupiter : MonoBehaviour
{
    public GameObject PanelInfoYupiter;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoYupiter.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoYupiter.SetActive(false);
            show = false;
        }
    }
}
