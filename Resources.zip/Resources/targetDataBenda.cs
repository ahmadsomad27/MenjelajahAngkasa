﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

namespace Vuforia
{
    public class targetDataBenda : MonoBehaviour
    {

        public Transform TextTargetName;
        //public Transform TextDescription;
        public Transform ButtonAction;
        //public Transform PanelDescription;
        public Transform ZoomIn;
        public Transform ZoomOut;
        public Transform rotasi;
        public AudioSource soundTarget;
        public AudioClip clipTarget;
        public Transform btnBulan;
        public Transform btnAsteroid;
        public Transform btnMeteoroid;
        public Transform btnMeteor;
        public Transform btnMeteorit;
        public Transform btnBintang;
        public Transform btnKomet;
        public Transform btnMatahari;
        //public Transform kubus;

        //public GameObject bumi;
        //public GameObject merkurius;

        // Use this for initialization
        void Start()
        {
            //add Audio Source as new game object component
            soundTarget = (AudioSource)gameObject.AddComponent<AudioSource>();
        }

        // Update is called once per frame
        void Update()
        {
            StateManager sm = TrackerManager.Instance.GetStateManager();
            IEnumerable<TrackableBehaviour> tbs = sm.GetActiveTrackableBehaviours();
            IList<TrackableBehaviour> activeTrackable = (IList<TrackableBehaviour>)sm.GetActiveTrackableBehaviours();

            foreach (TrackableBehaviour tb in tbs)
            {
                string name = tb.TrackableName;
                ImageTarget it = tb.Trackable as ImageTarget;
                Vector2 size = it.GetSize();

                //Debug.Log("Active image target:" + name + "  -size: " + size.x + ", " + size.y);

                //Evertime the target found it will show “name of target” on the TextTargetName. Button, Description and Panel will visible (active)

                TextTargetName.GetComponent<Text>().text = name;
                ButtonAction.gameObject.SetActive(true);
                ZoomIn.gameObject.SetActive(true);
                ZoomOut.gameObject.SetActive(true);
                rotasi.gameObject.SetActive(true);
                btnBulan.gameObject.SetActive(true);
                btnAsteroid.gameObject.SetActive(true);
                btnMeteoroid.gameObject.SetActive(true);
                btnMeteor.gameObject.SetActive(true);
                btnMeteorit.gameObject.SetActive(true);
                btnBintang.gameObject.SetActive(true);
                btnKomet.gameObject.SetActive(true);
                btnMatahari.gameObject.SetActive(true);


                if (activeTrackable.Count > 1)
                {
                    TextTargetName.GetComponent<Text>().text = "Benda Langit";
                    ButtonAction.gameObject.SetActive(false);
                    btnBulan.gameObject.SetActive(false);
                    btnAsteroid.gameObject.SetActive(false);
                    btnMeteoroid.gameObject.SetActive(false);
                    btnMeteor.gameObject.SetActive(false);
                    btnMeteorit.gameObject.SetActive(false);
                    btnBintang.gameObject.SetActive(false);
                    btnKomet.gameObject.SetActive(false);
                    btnMatahari.gameObject.SetActive(false);
                }
                else
                {
                    if (name == "Bulan")
                    {
                        ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Bulan"); });
                        btnBulan.gameObject.SetActive(true);
                        btnAsteroid.gameObject.SetActive(false);
                        btnMeteoroid.gameObject.SetActive(false);
                        btnMeteor.gameObject.SetActive(false);
                        btnMeteorit.gameObject.SetActive(false);
                        btnBintang.gameObject.SetActive(false);
                        btnKomet.gameObject.SetActive(false);
                        btnMatahari.gameObject.SetActive(false);
                    }

                    if (name == "Asteroid")
                    {
                        ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Asteroid"); });
                        btnBulan.gameObject.SetActive(false);
                        btnAsteroid.gameObject.SetActive(true);
                        btnMeteoroid.gameObject.SetActive(false);
                        btnMeteor.gameObject.SetActive(false);
                        btnMeteorit.gameObject.SetActive(false);
                        btnBintang.gameObject.SetActive(false);
                        btnKomet.gameObject.SetActive(false);
                        btnMatahari.gameObject.SetActive(false);
                    }

                    if (name == "Meteoroid")
                    {
                        ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Meteoroid"); });
                        btnBulan.gameObject.SetActive(false);
                        btnAsteroid.gameObject.SetActive(false);
                        btnMeteoroid.gameObject.SetActive(true);
                        btnMeteor.gameObject.SetActive(false);
                        btnMeteorit.gameObject.SetActive(false);
                        btnBintang.gameObject.SetActive(false);
                        btnKomet.gameObject.SetActive(false);
                        btnMatahari.gameObject.SetActive(false);
                    }

                    if (name == "Meteor")
                    {
                        ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Meteor"); });
                        btnBulan.gameObject.SetActive(false);
                        btnAsteroid.gameObject.SetActive(false);
                        btnMeteoroid.gameObject.SetActive(false);
                        btnMeteor.gameObject.SetActive(true);
                        btnMeteorit.gameObject.SetActive(false);
                        btnBintang.gameObject.SetActive(false);
                        btnKomet.gameObject.SetActive(false);
                        btnMatahari.gameObject.SetActive(false);
                    }

                    if (name == "Meteorit")
                    {
                        ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Meteorit"); });
                        rotasi.gameObject.SetActive(false);
                        btnBulan.gameObject.SetActive(false);
                        btnAsteroid.gameObject.SetActive(false);
                        btnMeteoroid.gameObject.SetActive(false);
                        btnMeteor.gameObject.SetActive(false);
                        btnMeteorit.gameObject.SetActive(true);
                        btnBintang.gameObject.SetActive(false);
                        btnKomet.gameObject.SetActive(false);
                        btnMatahari.gameObject.SetActive(false);
                    }

                    if (name == "Bintang")
                    {
                        ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Bintang"); });
                        btnBulan.gameObject.SetActive(false);
                        btnAsteroid.gameObject.SetActive(false);
                        btnMeteoroid.gameObject.SetActive(false);
                        btnMeteor.gameObject.SetActive(false);
                        btnMeteorit.gameObject.SetActive(false);
                        btnBintang.gameObject.SetActive(true);
                        btnKomet.gameObject.SetActive(false);
                        btnMatahari.gameObject.SetActive(false);
                    }

                    if (name == "Komet")
                    {
                        ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Komet"); });
                        btnBulan.gameObject.SetActive(false);
                        btnAsteroid.gameObject.SetActive(false);
                        btnMeteoroid.gameObject.SetActive(false);
                        btnMeteor.gameObject.SetActive(false);
                        btnMeteorit.gameObject.SetActive(false);
                        btnBintang.gameObject.SetActive(false);
                        btnKomet.gameObject.SetActive(true);
                        btnMatahari.gameObject.SetActive(false);
                    }

                    if (name == "Matahari")
                    {
                        ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Matahari"); });
                        btnBulan.gameObject.SetActive(false);
                        btnAsteroid.gameObject.SetActive(false);
                        btnMeteoroid.gameObject.SetActive(false);
                        btnMeteor.gameObject.SetActive(false);
                        btnMeteorit.gameObject.SetActive(false);
                        btnBintang.gameObject.SetActive(false);
                        btnKomet.gameObject.SetActive(false);
                        btnMatahari.gameObject.SetActive(true);
                    }
                }

               // if (bumi.activeInHierarchy && merkurius.activeInHierarchy)
                //{

                  //      TextTargetName.GetComponent<Text>().text = "Gerhana";
                    //    ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Komet"); });
                      //  btnBulan.gameObject.SetActive(false);
                        //btnAsteroid.gameObject.SetActive(false);
                        //btnMeteoroid.gameObject.SetActive(false);
                        //btnMeteor.gameObject.SetActive(false);
                        //btnMeteorit.gameObject.SetActive(false);
                        //btnBintang.gameObject.SetActive(false);
                        //btnKomet.gameObject.SetActive(true);
                        //kubus.gameObject.SetActive(true);
                //}
                

            }
            
        }
        

    //function to play sound
    void playSound(string ss)
        {
            clipTarget = (AudioClip)Resources.Load(ss);
            soundTarget.clip = clipTarget;
            soundTarget.loop = false;
            soundTarget.playOnAwake = false;
            soundTarget.Play();
        }
    }
}