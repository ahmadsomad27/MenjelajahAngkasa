﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SoalManager : MonoBehaviour
{
    [System.Serializable]
    public class Soal
    {
        [TextArea]
        [Header("Soal")]
        public string soal;

        [Header("Pilihan Jawaban")]
        public string pilA;
        public string pilB, pilC, pilD;

        [Header("Kunci Jawaban")]
        public bool A;
        public bool B, C, D;
        
    }

    public GameObject selesai;
    public GameObject backHome;
    public GameObject medaliNilai;
    public int skor;
    public float waktu;
    private int nilaiAcak;
    Text textSoal, textA, textB, textC, textD, textWaktu;
    public Text highScore;
    public List<Soal> KumpulanSoal;
    

    public GameObject benar, salah, waktuIkon;

    // Start is called before the first frame update
    void Start()
    {
        textSoal = GameObject.Find("TextSoal").GetComponent<Text>();
        textA = GameObject.Find("A").GetComponent<Text>();
        textB = GameObject.Find("B").GetComponent<Text>();
        textC = GameObject.Find("C").GetComponent<Text>();
        textD = GameObject.Find("D").GetComponent<Text>();

        textWaktu = GameObject.Find("TextWaktu").GetComponent<Text>();
        highScore.text = PlayerPrefs.GetInt("HighScore", 0).ToString();

        nilaiAcak = Random.RandomRange(0,KumpulanSoal.Count);
    } 

    // Update is called once per frame
    void Update()
    {
        textWaktu.text = " " + waktu.ToString("0");
        waktu -= Time.deltaTime;
        

        if (waktu <= 0)
        {
            KumpulanSoal.RemoveAt(nilaiAcak);
            waktu = 20;
            nilaiAcak = Random.RandomRange(0, KumpulanSoal.Count);
            waktuIkon.SetActive(false);
            waktuIkon.SetActive(true);
        }
        if (KumpulanSoal.Count > 0)
        {
            textSoal.text = KumpulanSoal[nilaiAcak].soal;
            textA.text = KumpulanSoal[nilaiAcak].pilA;
            textB.text = KumpulanSoal[nilaiAcak].pilB;
            textC.text = KumpulanSoal[nilaiAcak].pilC;
            textD.text = KumpulanSoal[nilaiAcak].pilD;
        }
        else
        {
            selesai.SetActive(true);
            backHome.SetActive(true);
            medaliNilai.SetActive(true);
            textSoal.text = skor.ToString();
            textSoal.fontSize  = 120;
            //menampilkan dan update nilai tertinggi
            if (skor > PlayerPrefs.GetInt("HighScore", 0))
            {
                PlayerPrefs.SetInt("HighScore", skor);
                highScore.text = skor.ToString();
            }
            GameObject.Find("bgSoal").SetActive(false);
            GameObject.Find("TextWaktu").SetActive(false);
            GameObject.Find("Panel").SetActive(false);
            GameObject.Find("LogoWaktu").SetActive(false);
        }
        
    }

    /*public void Reset()
    {
        PlayerPrefs.DeleteAll();
        highScore.text = "0";
    }*/

    public void CekJawaban(string jawaban)
    {
        if (KumpulanSoal[nilaiAcak].A==true && jawaban=="a")
        {
            skor+=4;
            benar.SetActive(false);
            benar.SetActive(true);
        }
        if (KumpulanSoal[nilaiAcak].B == true && jawaban == "b")
        {
            skor+=4;
            benar.SetActive(false);
            benar.SetActive(true);
        }
        if (KumpulanSoal[nilaiAcak].C == true && jawaban == "c")
        {
            skor+=4;
            benar.SetActive(false);
            benar.SetActive(true);
        }
        if (KumpulanSoal[nilaiAcak].D == true && jawaban == "d")
        {
            skor+=4;
            benar.SetActive(false);
            benar.SetActive(true);
        }
        if (KumpulanSoal[nilaiAcak].A == false && jawaban == "a")
        {
            salah.SetActive(false);
            salah.SetActive(true);
        }
        if (KumpulanSoal[nilaiAcak].B == false && jawaban == "b")
        {
            salah.SetActive(false);
            salah.SetActive(true);
        }
        if (KumpulanSoal[nilaiAcak].C == false && jawaban == "c")
        {
            salah.SetActive(false);
            salah.SetActive(true);
        }
        if (KumpulanSoal[nilaiAcak].D == false && jawaban == "d")
        {
            salah.SetActive(false);
            salah.SetActive(true);
        }
        KumpulanSoal.RemoveAt(nilaiAcak);
        nilaiAcak = Random.RandomRange(0 , KumpulanSoal.Count);
        waktu = 20;
    }

    public void ulang()
    {
        Application.LoadLevel(Application.loadedLevel);
    }
    public void home()
    {
        Application.LoadLevel("main_menu");
    }
}
