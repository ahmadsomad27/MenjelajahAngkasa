﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerBumi : MonoBehaviour
{
    public GameObject PanelInfoBumi;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoBumi.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoBumi.SetActive(false);
            show = false;
        }
    }
}
