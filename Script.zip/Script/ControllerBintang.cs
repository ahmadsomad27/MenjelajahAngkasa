using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerBintang : MonoBehaviour
{
    public GameObject PanelInfoBintang;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoBintang.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoBintang.SetActive(false);
            show = false;
        }
    }
}
