﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ARRotasi : MonoBehaviour
{
    public GameObject objectRotateMerkurius;
    public GameObject objectRotateVenus;
    public GameObject objectRotateBumi;
    public GameObject objectRotateMars;
    public GameObject objectRotateYupiter;
    public GameObject objectRotateSaturnus;
    public GameObject objectRotateUranus;
    public GameObject objectRotateNeptunus;

    public float rotateSpeed = 50f;
    bool rotateStatus = false;

    public void Rotasi()
    {
        if(rotateStatus == false)
        {
            rotateStatus = true;
        }
        else
        {
            rotateStatus = false;
        }
    }

    private void Update()
    {
        if(rotateStatus == true)
        {
            objectRotateMerkurius.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateVenus.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateBumi.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateMars.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateYupiter.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateSaturnus.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateUranus.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateNeptunus.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
        }
    }
}
