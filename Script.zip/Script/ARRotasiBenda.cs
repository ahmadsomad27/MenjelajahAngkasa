﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ARRotasiBenda : MonoBehaviour
{
    public GameObject objectRotateAsteroid;
    public GameObject objectRotateMateoroid;
    public GameObject objectRotateMeteor;
    public GameObject objectRotateMeteorit;
    public GameObject objectRotateKomet;
    public GameObject objectRotateBintang;
    public GameObject objectRotateMatahari;
    public GameObject objectRotateBulan;

    public float rotateSpeed = 50f;
    bool rotateStatus = false;

    public void Rotasi()
    {
        if (rotateStatus == false)
        {
            rotateStatus = true;
        }
        else
        {
            rotateStatus = false;
        }
    }

    private void Update()
    {
        if (rotateStatus == true)
        {
            objectRotateAsteroid.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateMateoroid.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateMeteor.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateMeteorit.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateKomet.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateBintang.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateMatahari.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            objectRotateBulan.transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
        }
    }
}
