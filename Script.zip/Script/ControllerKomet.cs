using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerKomet : MonoBehaviour
{
    public GameObject PanelInfoKomet;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoKomet.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoKomet.SetActive(false);
            show = false;
        }
    }
}
