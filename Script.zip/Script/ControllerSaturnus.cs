﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerSaturnus : MonoBehaviour
{
    public GameObject PanelInfoSaturnus;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoSaturnus.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoSaturnus.SetActive(false);
            show = false;
        }
    }
}
