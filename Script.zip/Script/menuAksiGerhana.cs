﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class menuAksiGerhana : MonoBehaviour
{
    public void menuScan()
    {
        Application.LoadLevel("menuScan");
    }
    public void menuGerhana()
    {
        Application.LoadLevel("menuGerhana");
    }
    public void materiMTotal()
    {
        Application.LoadLevel("materiMTotal");
    }
    public void materiMSebagian()
    {
        Application.LoadLevel("materiMSebagian");
    }
    public void materiMCincin()
    {
        Application.LoadLevel("materiMCincin");
    }
    public void materiMHibrid()
    {
        Application.LoadLevel("materiMHibrid");
    }
    public void materiBTotal()
    {
        Application.LoadLevel("materiBTotal");
    }
    public void materiBSebagian()
    {
        Application.LoadLevel("materiBSebagian");
    }
    public void materiBPenumbra()
    {
        Application.LoadLevel("materiBPenumbra");
    }
    public void mTotal()
    {
        Application.LoadLevel("mTotal");
    }
    public void mSebagian()
    {
        Application.LoadLevel("mSebagian");
    }
    public void mCincin()
    {
        Application.LoadLevel("mCincin");
    }
    public void mHibrid()
    {
        Application.LoadLevel("mHibrid");
    }
    public void bTotal()
    {
        Application.LoadLevel("bTotal");
    }
    public void bSebagian()
    {
        Application.LoadLevel("bSebagian");
    }
    public void bPenumbra()
    {
        Application.LoadLevel("bPenumbra");
    }
}
