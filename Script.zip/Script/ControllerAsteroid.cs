using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerAsteroid : MonoBehaviour
{
    public GameObject PanelInfoAsteroid;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoAsteroid.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoAsteroid.SetActive(false);
            show = false;
        }
    }
}
