using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerMeteoroid : MonoBehaviour
{
    public GameObject PanelInfoMeteoroid;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoMeteoroid.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoMeteoroid.SetActive(false);
            show = false;
        }
    }
}
