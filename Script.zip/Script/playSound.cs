﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playSound : MonoBehaviour
{
    public AudioSource lagu1, lagu2, touch;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    private void OnMouseDown()
    {
        touch.Play();
        if(gameObject.name == "lg1")
        {
            lagu1.Play();
            lagu2.Stop();
        }
        else
        {
            lagu1.Stop();
            lagu2.Play();
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
