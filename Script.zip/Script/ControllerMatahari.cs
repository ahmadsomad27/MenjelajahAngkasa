using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerMatahari : MonoBehaviour
{
    public GameObject PanelInfoMatahari;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoMatahari.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoMatahari.SetActive(false);
            show = false;
        }
    }
}
