﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerTataSurya : MonoBehaviour
{
    public GameObject PanelInfoTataSurya;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoTataSurya.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoTataSurya.SetActive(false);
            show = false;
        }
    }
}