﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class animasiBulanPenumbra : MonoBehaviour
{
    public Animator animatorPenumbra;
    public Transform objekBulanPenumbra;
    public Animator animator3D;
    public Transform objek3D;
    public Transform btnPlay;

    // Start is called before the first frame update
    void Start()
    {
        animatorPenumbra = objekBulanPenumbra.GetComponent<Animator>();
        animator3D = objek3D.GetComponent<Animator>();
    }

    // Update is called once per frame
    public void resumeAnimation()
    {
        animatorPenumbra.Play("gerhanaPenumbra");
        animator3D.Play("BulanPenumbra");
        animatorPenumbra.speed = 1;
        animator3D.speed = 1;
        Button btn = btnPlay.GetComponent<Button>();
        btn.onClick.AddListener(pauseAnimation);
    }
    void pauseAnimation()
    {
        animatorPenumbra.Play("stop");
        animator3D.Play("stop");
        animatorPenumbra.speed = 0;
        animator3D.speed = 0;
        Button btn = btnPlay.GetComponent<Button>();
        btn.onClick.AddListener(resumeAnimation);
    }
}