﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerUranus : MonoBehaviour
{
    public GameObject PanelInfoUranus;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoUranus.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoUranus.SetActive(false);
            show = false;
        }
    }
}
