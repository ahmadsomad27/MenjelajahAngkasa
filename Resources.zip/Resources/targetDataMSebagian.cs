﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

namespace Vuforia
{
    public class targetDataMSebagian : MonoBehaviour
{
        public Transform TextTargetName;
        public AudioSource soundTarget;
        public AudioClip clipTarget;

        //inisialisasi button
        public Transform ZoomIn;
        public Transform ZoomOut;
        public Transform btnAudio;
        public Transform btnAnimasi;

        //inisialisasi animasi 2d gerhana
        public GameObject gerhana2d;
        public GameObject gerhana3d;

        //inisialisasi objek
        public GameObject Matahari;
        public GameObject Bumi;
        public GameObject Sebagian;

        void MatahariSebagian()
        {
            float objMatahari = Matahari.transform.position.x;
            float objSebagian = Sebagian.transform.position.x;
            float objBumi = Bumi.transform.position.x;

            if (objMatahari < objSebagian && objSebagian < objBumi)
            {
                TextTargetName.GetComponent<Text>().text = "Gerhana Matahari Sebagian";
                btnAudio.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/mSebagian"); });
                btnAudio.gameObject.SetActive(true);
                ZoomIn.gameObject.SetActive(true);
                ZoomOut.gameObject.SetActive(true);
                btnAnimasi.gameObject.SetActive(true);
                gerhana2d.gameObject.SetActive(true);
                gerhana3d.gameObject.SetActive(true);
                Matahari.gameObject.SetActive(false);
                Bumi.gameObject.SetActive(false);
                Sebagian.gameObject.SetActive(false);
            }
            else
            {
                TextTargetName.GetComponent<Text>().text = "Susunan Salah";
                btnAudio.gameObject.SetActive(false);
                ZoomIn.gameObject.SetActive(false);
                ZoomOut.gameObject.SetActive(false);
                btnAnimasi.gameObject.SetActive(false);
                gerhana2d.gameObject.SetActive(false);
                gerhana3d.gameObject.SetActive(false);
                Matahari.gameObject.SetActive(true);
                Bumi.gameObject.SetActive(true);
                Sebagian.gameObject.SetActive(true);
            }
        }

        void BukanGerhana()
        {
            TextTargetName.GetComponent<Text>().text = "Susunan Salah";
        }

        // Start is called before the first frame update
        void Start()
        {
            //add Audio Source as new game object component
            soundTarget = (AudioSource)gameObject.AddComponent<AudioSource>();
        }

        void Update()
        {
            StateManager sm = TrackerManager.Instance.GetStateManager();
            IEnumerable<TrackableBehaviour> tbs = sm.GetActiveTrackableBehaviours();

            Matahari.SetActive(false);
            Bumi.SetActive(false);
            Sebagian.SetActive(false);

            foreach (TrackableBehaviour tb in tbs)
            {
                string name = tb.TrackableName;
                ImageTarget it = tb.Trackable as ImageTarget;
                Vector2 size = it.GetSize();

                //Debug.Log("Active image target:" + name + "  -size: " + size.x + ", " + size.y);

                //Evertime the target found it will show “name of target” on the TextTargetName. Button, Description and Panel will visible (active)

                TextTargetName.GetComponent<Text>().text = name;
                Matahari.SetActive(true);
                Bumi.SetActive(true);
                Sebagian.SetActive(true);

                ZoomIn.gameObject.SetActive(true);
                ZoomOut.gameObject.SetActive(true);
                btnAudio.gameObject.SetActive(true);
                btnAnimasi.gameObject.SetActive(true);
                gerhana2d.gameObject.SetActive(true);
                gerhana3d.gameObject.SetActive(true);

                if (Matahari.activeInHierarchy && Sebagian.activeInHierarchy && Bumi.activeInHierarchy)
                {
                    MatahariSebagian();
                }
                else if (Matahari.activeInHierarchy && Sebagian.activeInHierarchy)
                {
                    BukanGerhana();
                }
                else if (Matahari.activeInHierarchy && Bumi.activeInHierarchy)
                {
                    BukanGerhana();
                }
                else if (Bumi.activeInHierarchy && Sebagian.activeInHierarchy)
                {
                    BukanGerhana();
                }
                else if (Matahari.activeInHierarchy)
                {
                    BukanGerhana();
                }
                else if (Sebagian.activeInHierarchy)
                {
                    BukanGerhana();
                }
                else if (Bumi.activeInHierarchy)
                {
                    BukanGerhana();
                }

            }

        }


        //function to play sound
        void playSound(string ss)
        {
            clipTarget = (AudioClip)Resources.Load(ss);
            soundTarget.clip = clipTarget;
            soundTarget.loop = false;
            soundTarget.playOnAwake = false;
            soundTarget.Play();
        }
    }
}
