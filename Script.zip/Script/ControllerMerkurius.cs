﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerMerkurius : MonoBehaviour {

    public GameObject PanelInfoMerkurius;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoMerkurius.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoMerkurius.SetActive(false);
            show = false;
        }
    }
}
