﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

namespace Vuforia
{
    public class targetData : MonoBehaviour
    {

        public Transform TextTargetName;
        //public Transform TextDescription;
        public Transform ButtonAction;
        //public Transform PanelDescription;
        public Transform ZoomIn;
        public Transform ZoomOut;
        public Transform rotasi;
        public AudioSource soundTarget;
        public AudioClip clipTarget;
        public Transform btnTataSurya;
        public Transform btnMerkurius;
        public Transform btnVenus;
        public Transform btnBumi;
        public Transform btnMars;
        public Transform btnYupiter;
        public Transform btnSaturnus;
        public Transform btnUranus;
        public Transform btnNeptunus;

        // Use this for initialization
        void Start()
        {
        //add Audio Source as new game object component
            soundTarget = (AudioSource)gameObject.AddComponent<AudioSource>();
        }

        // Update is called once per frame
        void Update()
        {
            StateManager sm = TrackerManager.Instance.GetStateManager();
            IEnumerable<TrackableBehaviour> tbs = sm.GetActiveTrackableBehaviours();
            IList<TrackableBehaviour> activeTrackable = (IList<TrackableBehaviour>)sm.GetActiveTrackableBehaviours();

            foreach (TrackableBehaviour tb in tbs)
            {
                string name = tb.TrackableName;
                ImageTarget it = tb.Trackable as ImageTarget;
                Vector2 size = it.GetSize();

                Debug.Log("Active image target:" + name + "  -size: " + size.x + ", " + size.y);

                //Evertime the target found it will show “name of target” on the TextTargetName. Button, Description and Panel will visible (active)

                TextTargetName.GetComponent<Text>().text = name;
                ButtonAction.gameObject.SetActive(true);
                ZoomIn.gameObject.SetActive(true);
                ZoomOut.gameObject.SetActive(true);
                rotasi.gameObject.SetActive(true);
                btnTataSurya.gameObject.SetActive(true);
                btnMerkurius.gameObject.SetActive(true);
                btnVenus.gameObject.SetActive(true);
                btnBumi.gameObject.SetActive(true);
                btnMars.gameObject.SetActive(true);
                btnYupiter.gameObject.SetActive(true);
                btnSaturnus.gameObject.SetActive(true);
                btnUranus.gameObject.SetActive(true);
                btnNeptunus.gameObject.SetActive(true);
                //TextDescription.gameObject.SetActive(true);
                //PanelDescription.gameObject.SetActive(true);

                //if (name == "merkurius")
                //{
                //btnMerkurius.gameObject.SetActive(true);
                //btnVenus.gameObject.SetActive(false);
                //}
                //if(name == "venus")
                //{
                //btnMerkurius.gameObject.SetActive(false);
                //btnVenus.gameObject.SetActive(true);
                //}
                
                if(activeTrackable.Count > 1)
                {
                    TextTargetName.GetComponent<Text>().text = "Planet";
                    ButtonAction.gameObject.SetActive(false);
                    btnMerkurius.gameObject.SetActive(false);
                    btnVenus.gameObject.SetActive(false);
                    btnBumi.gameObject.SetActive(false);
                    btnMars.gameObject.SetActive(false);
                    btnYupiter.gameObject.SetActive(false);
                    btnSaturnus.gameObject.SetActive(false);
                    btnUranus.gameObject.SetActive(false);
                    btnNeptunus.gameObject.SetActive(false);
                    btnTataSurya.gameObject.SetActive(false);
                }
                else
                {
                if (name == "Merkurius") {
                    ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Merkurius"); });
                    btnMerkurius.gameObject.SetActive(true);
                    btnVenus.gameObject.SetActive(false);
                    btnBumi.gameObject.SetActive(false);
                    btnMars.gameObject.SetActive(false);
                    btnYupiter.gameObject.SetActive(false);
                    btnSaturnus.gameObject.SetActive(false);
                    btnUranus.gameObject.SetActive(false);
                    btnNeptunus.gameObject.SetActive(false);
                    btnTataSurya.gameObject.SetActive(false);
                }

                if (name == "Venus")
                {
                    ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Venus"); });
                    btnMerkurius.gameObject.SetActive(false);
                    btnVenus.gameObject.SetActive(true);
                    btnBumi.gameObject.SetActive(false);
                    btnMars.gameObject.SetActive(false);
                    btnYupiter.gameObject.SetActive(false);
                    btnSaturnus.gameObject.SetActive(false);
                    btnUranus.gameObject.SetActive(false);
                    btnNeptunus.gameObject.SetActive(false);
                    btnTataSurya.gameObject.SetActive(false);
                }

                if (name == "Bumi")
                {
                    ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Bumi"); });
                    btnMerkurius.gameObject.SetActive(false);
                    btnVenus.gameObject.SetActive(false);
                    btnBumi.gameObject.SetActive(true);
                    btnMars.gameObject.SetActive(false);
                    btnYupiter.gameObject.SetActive(false);
                    btnSaturnus.gameObject.SetActive(false);
                    btnUranus.gameObject.SetActive(false);
                    btnNeptunus.gameObject.SetActive(false);
                    btnTataSurya.gameObject.SetActive(false);
                }

                if (name == "Mars")
                {
                    ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Mars"); });
                    btnMerkurius.gameObject.SetActive(false);
                    btnVenus.gameObject.SetActive(false);
                    btnBumi.gameObject.SetActive(false);
                    btnMars.gameObject.SetActive(true);
                    btnYupiter.gameObject.SetActive(false);
                    btnSaturnus.gameObject.SetActive(false);
                    btnUranus.gameObject.SetActive(false);
                    btnNeptunus.gameObject.SetActive(false);
                    btnTataSurya.gameObject.SetActive(false);
                }

                if (name == "Yupiter")
                {
                    ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Yupiter"); });
                    btnMerkurius.gameObject.SetActive(false);
                    btnVenus.gameObject.SetActive(false);
                    btnBumi.gameObject.SetActive(false);
                    btnMars.gameObject.SetActive(false);
                    btnYupiter.gameObject.SetActive(true);
                    btnSaturnus.gameObject.SetActive(false);
                    btnUranus.gameObject.SetActive(false);
                    btnNeptunus.gameObject.SetActive(false);
                    btnTataSurya.gameObject.SetActive(false);
                }

                if (name == "Saturnus")
                {
                    ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Saturnus"); });
                    btnMerkurius.gameObject.SetActive(false);
                    btnVenus.gameObject.SetActive(false);
                    btnBumi.gameObject.SetActive(false);
                    btnMars.gameObject.SetActive(false);
                    btnYupiter.gameObject.SetActive(false);
                    btnSaturnus.gameObject.SetActive(true);
                    btnUranus.gameObject.SetActive(false);
                    btnNeptunus.gameObject.SetActive(false);
                    btnTataSurya.gameObject.SetActive(false);
                }

                if (name == "Uranus")
                {
                    ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Uranus"); });
                    btnMerkurius.gameObject.SetActive(false);
                    btnVenus.gameObject.SetActive(false);
                    btnBumi.gameObject.SetActive(false);
                    btnMars.gameObject.SetActive(false);
                    btnYupiter.gameObject.SetActive(false);
                    btnSaturnus.gameObject.SetActive(false);
                    btnUranus.gameObject.SetActive(true);
                    btnNeptunus.gameObject.SetActive(false);
                    btnTataSurya.gameObject.SetActive(false);
                }

                if (name == "Neptunus")
                {
                    ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/Neptunus"); });
                    btnMerkurius.gameObject.SetActive(false);
                    btnVenus.gameObject.SetActive(false);
                    btnBumi.gameObject.SetActive(false);
                    btnMars.gameObject.SetActive(false);
                    btnYupiter.gameObject.SetActive(false);
                    btnSaturnus.gameObject.SetActive(false);
                    btnUranus.gameObject.SetActive(false);
                    btnNeptunus.gameObject.SetActive(true);
                    btnTataSurya.gameObject.SetActive(false);
                }
                if (name == "Tata_Surya")
                {
                    ButtonAction.GetComponent<Button>().onClick.AddListener(delegate { playSound("sounds/TataSurya"); });
                    btnMerkurius.gameObject.SetActive(false);
                    btnVenus.gameObject.SetActive(false);
                    btnBumi.gameObject.SetActive(false);
                    btnMars.gameObject.SetActive(false);
                    btnYupiter.gameObject.SetActive(false);
                    btnSaturnus.gameObject.SetActive(false);
                    btnUranus.gameObject.SetActive(false);
                    btnNeptunus.gameObject.SetActive(false);
                    rotasi.gameObject.SetActive(false);
                    btnTataSurya.gameObject.SetActive(true);
                }
                }
                //if (name == "Matahari")
                //{
                //TextTargetName.GetComponent<Text>().text = "Marker Tidak Terdeteksi";
                //ButtonAction.gameObject.SetActive(false);
                //ZoomIn.gameObject.SetActive(false);
                //ZoomOut.gameObject.SetActive(false);
                //btnMerkurius.gameObject.SetActive(false);
                //btnVenus.gameObject.SetActive(false);
                //btnBumi.gameObject.SetActive(false);
                //btnMars.gameObject.SetActive(false);
                //btnYupiter.gameObject.SetActive(false);
                //btnSaturnus.gameObject.SetActive(false);
                //btnUranus.gameObject.SetActive(false);
                //btnNeptunus.gameObject.SetActive(false);
                //}

            }
            
        }
//function to play sound
        void playSound(string ss){
            clipTarget = (AudioClip)Resources.Load(ss);
            soundTarget.clip = clipTarget;
            soundTarget.loop = false;
            soundTarget.playOnAwake = false;
            soundTarget.Play();
        }
    }
}