﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class animasiGerhanaHibrid : MonoBehaviour
{
    public Animator animatorBulan;
    public Transform objekBulan;
    public Animator animator3D;
    public Transform objek3D;
    public Transform btnPlay;

    // Start is called before the first frame update
    void Start()
    {
        animatorBulan = objekBulan.GetComponent<Animator>();
        animator3D = objek3D.GetComponent<Animator>();
    }

    // Update is called once per frame
    public void resumeAnimation()
    {
        animatorBulan.Play("gerhanaHibrid");
        animator3D.Play("MatahariHibrid");
        animatorBulan.speed = 1;
        animator3D.speed = 1;
        Button btn = btnPlay.GetComponent<Button>();
        btn.onClick.AddListener(pauseAnimation);
    }
    void pauseAnimation()
    {
        animatorBulan.Play("stop");
        animator3D.Play("stop");
        animatorBulan.speed = 0;
        animator3D.speed = 0;
        Button btn = btnPlay.GetComponent<Button>();
        btn.onClick.AddListener(resumeAnimation);
    }
}