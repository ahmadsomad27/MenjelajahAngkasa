﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerNeptunus : MonoBehaviour
{
    public GameObject PanelInfoNeptunus;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoNeptunus.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoNeptunus.SetActive(false);
            show = false;
        }
    }
}
