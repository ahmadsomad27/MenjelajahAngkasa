using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerMeteorit : MonoBehaviour
{
    public GameObject PanelInfoMeteorit;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoMeteorit.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoMeteorit.SetActive(false);
            show = false;
        }
    }
}
