﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class menu : MonoBehaviour
{
    public void GoToMainMenu()
    {
        Application.LoadLevel("main_menu");
    }

    public void GoToMainMenuScan()
    {
        Application.LoadLevel("menuScan");
    }

    public void ARPlanet()
    {
        Application.LoadLevel("ARPlanet");
    }

    public void ARBendaLangit()
    {
        Application.LoadLevel("ARBendaLangit");
    }

    public void ARGerhana()
    {
        Application.LoadLevel("ARGerhana");
    }

    public void ExitApplication()
    {
        Application.Quit();
    }
}
