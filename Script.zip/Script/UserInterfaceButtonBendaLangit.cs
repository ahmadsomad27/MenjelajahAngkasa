﻿using UnityEngine;
using System.Collections;
using System.IO;

public class UserInterfaceButtonBendaLangit : MonoBehaviour
{
    public float scalingSpeed = 0.03f;
    public float rotationSpeed = 70.0f;
    public float translationSpeed = 5.0f;
    //	public GameObject Model;
    bool repeatScaleUp = false;
    bool repeatScaleDown = false;
    
    void Update()
    {
        if (repeatScaleUp)
        {
            ScaleUpButton();
        }

        if (repeatScaleDown)
        {
            ScaleDownButton();
        }
    }

    public void CloseAppButton()
    {
        Application.Quit();
    }

    public void ScaleUpButton()
    {
        // transform.localScale += new Vector3(scalingSpeed, scalingSpeed, scalingSpeed);
        GameObject.FindWithTag("Bulan").transform.localScale += new Vector3(scalingSpeed, scalingSpeed, scalingSpeed);
        GameObject.FindWithTag("Asteroid").transform.localScale += new Vector3(scalingSpeed, scalingSpeed, scalingSpeed);
        GameObject.FindWithTag("Meteoroid").transform.localScale += new Vector3(scalingSpeed, scalingSpeed, scalingSpeed);
        GameObject.FindWithTag("Meteor").transform.localScale += new Vector3(scalingSpeed, scalingSpeed, scalingSpeed);
        GameObject.FindWithTag("Meteorit").transform.localScale += new Vector3(scalingSpeed, scalingSpeed, scalingSpeed);
        GameObject.FindWithTag("Bintang").transform.localScale += new Vector3(scalingSpeed, scalingSpeed, scalingSpeed);
        GameObject.FindWithTag("Komet").transform.localScale += new Vector3(scalingSpeed, scalingSpeed, scalingSpeed);
        GameObject.FindWithTag("Matahari").transform.localScale += new Vector3(scalingSpeed, scalingSpeed, scalingSpeed);
    }

    public void ScaleUpButtonRepeat()
    {
        repeatScaleUp = true;
        Debug.Log("Up");
    }
    public void ScaleDownButtonRepeat()
    {
        repeatScaleDown = true;
        Debug.Log("Down");
    }
    public void ScaleUpButtonOff()
    {
        repeatScaleUp = false;
        Debug.Log("Off");
    }
    public void ScaleDownButtonOff()
    {
        repeatScaleDown = false;
        Debug.Log("Off");
    }

    public void ScaleDownButton()
    {
        // transform.localScale += new Vector3(-scalingSpeed, -scalingSpeed, -scalingSpeed);
        GameObject.FindWithTag("Bulan").transform.localScale += new Vector3(-scalingSpeed, -scalingSpeed, -scalingSpeed);
        GameObject.FindWithTag("Asteroid").transform.localScale += new Vector3(-scalingSpeed, -scalingSpeed, -scalingSpeed);
        GameObject.FindWithTag("Meteoroid").transform.localScale += new Vector3(-scalingSpeed, -scalingSpeed, -scalingSpeed);
        GameObject.FindWithTag("Meteor").transform.localScale += new Vector3(-scalingSpeed, -scalingSpeed, -scalingSpeed);
        GameObject.FindWithTag("Meteorit").transform.localScale += new Vector3(-scalingSpeed, -scalingSpeed, -scalingSpeed);
        GameObject.FindWithTag("Bintang").transform.localScale += new Vector3(-scalingSpeed, -scalingSpeed, -scalingSpeed);
        GameObject.FindWithTag("Komet").transform.localScale += new Vector3(-scalingSpeed, -scalingSpeed, -scalingSpeed);
        GameObject.FindWithTag("Matahari").transform.localScale += new Vector3(-scalingSpeed, -scalingSpeed, -scalingSpeed);
    }

    public void ChangeScene(string a)
    {
        Application.LoadLevel(a);
    }

    public void AnyButton()
    {
        Debug.Log("Any");
    }
}
