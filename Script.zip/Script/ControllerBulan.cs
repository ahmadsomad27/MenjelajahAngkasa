using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerBulan : MonoBehaviour
{
    public GameObject PanelInfoBulan;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoBulan.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoBulan.SetActive(false);
            show = false;
        }
    }
}
