﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerVenus : MonoBehaviour
{

    public GameObject PanelInfoVenus;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoVenus.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoVenus.SetActive(false);
            show = false;
        }
    }
}
