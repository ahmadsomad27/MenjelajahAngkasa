﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class menuAksi : MonoBehaviour
{
    public void ExitApplication()
    {
        Application.Quit ();
    }

    public void Home()
    {
        Application.LoadLevel("main_menu");
    }

    public void KembaliMenuScan()
    {
        Application.LoadLevel("menuScan");
    }

    public void Informasi()
    {
        Application.LoadLevel("slider");
    }

    public void Tentang()
    {
        Application.LoadLevel("tentang");
    }

    public void Setting()
    {
        Application.LoadLevel("setting");
    }
    public void awalKuis()
    {
        Application.LoadLevel("awalKuis");
    }
    public void Kuis(){
        Application.LoadLevel("kuis");
    }
    public void Gerhana(){
        Application.LoadLevel("menuGerhana");
    }
}
