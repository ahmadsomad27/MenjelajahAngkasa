using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerMeteor : MonoBehaviour
{
    public GameObject PanelInfoMeteor;

    private bool show = false;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfoMeteor.SetActive(true);
            show = true;
        }
        else
        {
            PanelInfoMeteor.SetActive(false);
            show = false;
        }
    }
}
