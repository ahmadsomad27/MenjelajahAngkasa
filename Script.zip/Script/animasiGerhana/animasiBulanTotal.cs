﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class animasiBulanTotal : MonoBehaviour
{
    public Animator animatorMerah;
    public Transform objekBulanMerah;
    public Animator animatorBulan;
    public Transform objekBulan;
    public Animator animator3D;
    public Transform objek3D;
    public Transform btnPlay;

    // Start is called before the first frame update
    void Start()
    {
        animatorMerah = objekBulanMerah.GetComponent<Animator>();
        animatorBulan = objekBulan.GetComponent<Animator>();
        animator3D = objek3D.GetComponent<Animator>();
    }

    // Update is called once per frame
    public void resumeAnimation()
    {
        animatorMerah.Play("bulanTotal");
        animatorBulan.Play("gerhana");
        animator3D.Play("BulanTotal");
        animatorMerah.speed = 1;
        animatorBulan.speed = 1;
        animator3D.speed = 1;
        Button btn = btnPlay.GetComponent<Button>();
        btn.onClick.AddListener(pauseAnimation);
    }
    void pauseAnimation()
    {
        animatorMerah.Play("stop");
        animatorBulan.Play("stop");
        animator3D.Play("stop");
        animatorMerah.speed = 0;
        animatorBulan.speed = 0;
        animator3D.speed = 0;
        Button btn = btnPlay.GetComponent<Button>();
        btn.onClick.AddListener(resumeAnimation);
    }
}
